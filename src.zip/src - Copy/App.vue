<template>
  <v-app>
    <v-card>
    <menu v-for="twit in timeline" v-bind:key="twit.id" v-bind:text="twit.full_text"></menu>
    </v-card>
    <div class='wow'>hello</div>
  </v-app>
</template>

<script>
import twitMenu from './components/twitMenu'
var timeline = new Array();
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "http://98.27.202.77/mvnu/testingFinal/test.php");
    xhr.onload = function() {
      if (xhr.status === 200) {
        timeline = eval(xhr.responseText);
        var testing = timeline[0].full_text;
        console.log(timeline);
      } else {
        alert("Request failed: " + xhr.status);
      }
    };
    xhr.send();
export default {
  name: 'App',
  components: {
    twitMenu
  },
  data () {
    return {
    timeline
    };
  }
};
</script>
