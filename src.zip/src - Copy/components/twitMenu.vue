<template>
  <v-container>
      <span>{{text}}</span>
      <div>hello</div>
  </v-container>
</template>

<script>
export default {
  name: "twitMenu",
  data: () => ({}),
  props: {
    text: String
  },
  mounted: function() {
    //console.log("hello");
    
  }
};
</script>

<style>
</style>
